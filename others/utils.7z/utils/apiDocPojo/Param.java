/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
public class Param {

    private Before before;
    private After after;
    private String name;
    private String id;
    private String remark;
    private List<Header> header;
    private List<QueryParam> queryParam;
    private List<BodyParam> bodyParam;
    private BodyInfo bodyInfo;
    private List<OutParam> outParam;
    private OutInfo outInfo;
    private List<String> restParam;
    public void setBefore(Before before) {
         this.before = before;
     }

}