package com.southsmart.smartwater.utils.apiDocPojo;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ZhangJiaKui
 * @classname ApiDocBeanDir
 * @description TODO
 * @date 12/30/2020 4:12 PM
 */
@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiDocDir {

        private String name;
        private String flag;
        //可能是分组文件夹,也有可能是单独的接口数据
        private List data;
}
