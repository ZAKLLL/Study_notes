/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@lombok.Data
public class Data {

    private String value;
    private String remark;
    public void setValue(String value) {
         this.value = value;
     }
     public String getValue() {
         return value;
     }

    public void setRemark(String remark) {
         this.remark = remark;
     }
     public String getRemark() {
         return remark;
     }

}