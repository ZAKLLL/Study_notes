/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@AllArgsConstructor
@Data
public class QueryParam {

    private String name;
    private int must;
    private String remark;
    private Value value;

}