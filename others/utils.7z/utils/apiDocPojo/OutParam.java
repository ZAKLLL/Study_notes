/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
public class OutParam {

    private String name;
    private int type;
    private String remark;
    private int must;
    private String mock;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setType(int type) {
         this.type = type;
     }
     public int getType() {
         return type;
     }

    public void setRemark(String remark) {
         this.remark = remark;
     }
     public String getRemark() {
         return remark;
     }

    public void setMust(int must) {
         this.must = must;
     }
     public int getMust() {
         return must;
     }

    public void setMock(String mock) {
         this.mock = mock;
     }
     public String getMock() {
         return mock;
     }

}