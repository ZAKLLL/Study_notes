/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;

import lombok.Data;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */

@Data
public class Before {

    private int mode=0;
    private String code="";

}