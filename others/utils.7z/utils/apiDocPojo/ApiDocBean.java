/**
  * Copyright 2020 json.cn 
  */
package com.southsmart.smartwater.utils.apiDocPojo;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Date;

/**
 * Auto-generated: 2020-12-30 14:47:34
 *
 * @author json.cn (i@json.cn)
 * @website http://www.json.cn/java2pojo/
 */
@Data
@AllArgsConstructor
public class ApiDocBean {

    private String flag;
    private List<Param> param;
    private int finish;
    private int sort;
    private String name;
    private String url;
    private String remark;
    private String method;
    private Date createdAt;
    private Date updatedAt;

}