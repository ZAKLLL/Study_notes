package com.southsmart.smartwater.utils;

import cn.hutool.core.lang.Dict;
import com.alibaba.fastjson.JSON;
import com.southsmart.microserver.log.annotation.OperationLog;
import com.southsmart.smartwater.utils.apiDocPojo.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.ToString;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.net.URL;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * @author ZhangJiaKui
 * @classname ApiUtils
 * @description TODO
 * @date 12/30/2020 11:37 AM
 */
public class ApiUtils {
    public final static String packageName = "com.southsmart.smartwater.controller";
    public final static boolean findPackage = true;

    public final static String outputDir = "C:\\Users\\10158\\Desktop\\分组接口信息\\";
    public final static Map<String, String> groupNameMap;

    static {
        groupNameMap = new HashMap<>();
        groupNameMap.put("MonitorWarningController", "预警监控模块");
        groupNameMap.put("MonitorZssController", "再生水监控模块");
        groupNameMap.put("MonitorVideoController", "视频监控模块");
        groupNameMap.put("MonitorSewageController", "污水厂监控模块");
    }

    public static void main(String[] args) throws IOException {
        genApiDocInJson();
    }

    public static void genApiDocInJson() throws IOException {
        Map<String, List<ApiInfo>> groupApi = genGroupApi();
        File file = new File(outputDir);
        if (!file.exists()) {
            file.mkdir();
        }
        ApiDocDir rootApiDocDir = new ApiDocDir();
        rootApiDocDir.setName("项目接口汇总文档");
        rootApiDocDir.setFlag("SBDoc");
        rootApiDocDir.setData(new ArrayList());
        for (Map.Entry<String, List<ApiInfo>> entry : groupApi.entrySet()) {
            String k = entry.getKey();
            List<ApiInfo> v = entry.getValue();
            System.out.println("生成 " + k + " 模块文档...");
            List<ApiDocBean> apiDocBeans = constructApiDocBeans(v);
            ApiDocDir apiDocDir = constructApiDocDir(k, apiDocBeans);
            rootApiDocDir.getData().add(apiDocDir);
            String groupJson = JSON.toJSONString(apiDocDir);
            exportGroupInfo(k, groupJson);
        }
        exportGroupInfo("项目接口汇总文档", JSON.toJSONString(rootApiDocDir));
    }

    public static void exportGroupInfo(String groupName, String groupJson) throws IOException {
        File groupJsonFile = new File(outputDir + groupNameMap.getOrDefault(groupName, groupName) + ".json");
        if (!groupJsonFile.exists()) {
            groupJsonFile.createNewFile();
        }
        try (FileWriter fileWriter = new FileWriter(groupJsonFile, false)) {
            fileWriter.write(groupJson);
            fileWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ApiDocDir constructApiDocDir(String groupName, List<ApiDocBean> apiDocBeans) {
        return new ApiDocDir(groupNameMap.getOrDefault(groupName, groupName), "SBDoc", apiDocBeans);
    }

    public static ApiDocBean constructApiDocBeans(ApiInfo apiInfo) {
        ArrayList<ApiInfo> apiInfos = new ArrayList<>();
        return constructApiDocBeans(apiInfos).get(0);
    }

    public static List<ApiDocBean> constructApiDocBeans(List<ApiInfo> apiInfos) {
        List<ApiDocBean> ret = new ArrayList<>();
        for (ApiInfo apiInfo : apiInfos) {
            List<Param> params = new ArrayList<>();
            List<Header> header = new ArrayList<>();
            List<QueryParam> queryParam = new ArrayList<>();
            List<BodyParam> bodyParam = new ArrayList<>();
            BodyInfo bodyInfo = new BodyInfo();
            List<OutParam> outParam = new ArrayList<>();
            OutInfo outInfo = new OutInfo();
            List<String> restParam = new ArrayList<>();

            //构建查询参数
            for (String s : apiInfo.getParamDict().keySet()) {
                queryParam.add(new QueryParam(s, 0, (String) apiInfo.getParamDict().get(s), new Value()));
            }
            Param param = new Param(new Before(), new After(), "参数", UUID.randomUUID().toString(), "", header, queryParam, bodyParam, bodyInfo, outParam, outInfo, restParam);
            params.add(param);
            ApiDocBean sbDoc = new ApiDocBean("SBDoc", params, 0, 0, apiInfo.getApiDetail(), apiInfo.getRequestPath(), "", apiInfo.getRequestMethods()[0].name(), new Date(), new Date());
            ret.add(sbDoc);
        }
        return ret;
    }

    //扫描指定路径下的controller注解

    @SneakyThrows
    public static Map<String, List<ApiInfo>> genGroupApi() {
        Map<String, List<ApiInfo>> groupApiMap = new HashMap<>();
        List<String> classNames = new ArrayList<>();
        if (findPackage) {
            classNames = getClassNames(packageName, true);
        } else {
            classNames.add(packageName);
        }
        ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        for (String className : classNames) {
            Class<?> cz = contextClassLoader.loadClass(className);
            for (Annotation annotation : cz.getAnnotations()) {
                if (annotation.annotationType().isAssignableFrom(Controller.class) || annotation.annotationType().isAssignableFrom(RestController.class)) {

                    String groupName = className.substring(className.lastIndexOf(".") + 1);
                    groupApiMap.put(groupName, new ArrayList<>());


                    RequestMapping rp = cz.getAnnotation(RequestMapping.class);
                    String prePath = rp.value()[0];

                    //public
                    Method[] methods = cz.getMethods();
                    for (Method method : methods) {
                        String operateDetail = null;
                        String path = null;
                        RequestMethod[] requestMethods = null;
                        for (Annotation methodAnnotation : method.getAnnotations()) {
                            Class<? extends Annotation> annotationType = methodAnnotation.annotationType();
                            if (annotationType.isAssignableFrom(RequestMapping.class)) {
                                RequestMapping requestMapping = method.getAnnotation(RequestMapping.class);
                                path = prePath + requestMapping.value()[0];
                                requestMethods = RequestMethod.values();
                            } else if (annotationType.isAssignableFrom(PostMapping.class)) {
                                PostMapping postMapping = method.getAnnotation(PostMapping.class);
                                path = prePath + postMapping.value()[0];
                                requestMethods = new RequestMethod[]{RequestMethod.POST};
                            } else if (annotationType.isAssignableFrom(GetMapping.class)) {
                                GetMapping getMapping = method.getAnnotation(GetMapping.class);
                                path = prePath + getMapping.value()[0];
                                requestMethods = new RequestMethod[]{RequestMethod.GET};
                            } else if (annotationType.isAssignableFrom(PutMapping.class)) {
                                PutMapping putMapping = method.getAnnotation(PutMapping.class);
                                path = prePath + putMapping.value()[0];
                                requestMethods = new RequestMethod[]{RequestMethod.PUT};
                            } else if (annotationType.isAssignableFrom(DeleteMapping.class)) {
                                DeleteMapping deleteMapping = method.getAnnotation(DeleteMapping.class);
                                path = prePath + deleteMapping.value()[0];
                                requestMethods = new RequestMethod[]{RequestMethod.DELETE};
                            }
                            if (methodAnnotation.annotationType().isAssignableFrom(OperationLog.class)) {
                                operateDetail = method.getAnnotation(OperationLog.class).detail();
                            }
                        }
                        if (path == null) continue;
                        //参数类型
                        Parameter[] parameters = method.getParameters();
                        Dict paramAndTypeDict = Dict.create();
                        for (Parameter parameter : parameters) {
                            Class<?> type = parameter.getType();
                            //request response 跳过
                            if (type.isAssignableFrom(HttpServletResponse.class) || type.isAssignableFrom(HttpServletRequest.class))
                                continue;
                            String name = parameter.getName();
                            paramAndTypeDict.set(name, type.getName());
                        }
                        if (groupName.equals("MonitorVideoController")) {
                            System.out.println();
                        }
                        groupApiMap.get(groupName).add(new ApiInfo(groupNameMap.getOrDefault(groupName, groupName), path, requestMethods, operateDetail, paramAndTypeDict, method.getReturnType().getName()));
                    }
                    break;
                }
            }
        }
        return groupApiMap;
    }


    private static List<String> getClassNames(String packageName, boolean childPackage) throws IOException {
        List<String> fileNames = new ArrayList<>();
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        String packagePath = packageName.replace(".", "/");
        Enumeration<URL> urls = loader.getResources(packagePath);
        while (urls.hasMoreElements()) {
            URL url = urls.nextElement();
            if (url == null)
                continue;
            String type = url.getProtocol();
            //支持开发阶段
            if (type.equals("file")) {
                fileNames.addAll(getAllClassNameByFile(new File(url.getPath()), childPackage, packageName));
            } else {
                fileNames.addAll(getClassNameByJar(url.getPath(), childPackage, packageName));
            }
        }
        return fileNames;
    }

    //获取类信息
    private static List<String> getAllClassNameByFile(File file, boolean flag, String packageName) {
        List<String> serviceLocationList = new ArrayList<>();
        File[] files = file.listFiles();
        if (files == null) {
            return serviceLocationList;
        }
        for (File f : files) {
            if (f.isFile()) {
                String path = f.getAbsolutePath();
                path = path.replaceAll("\\\\", ".");
                String fullName = path.substring(path.indexOf(packageName), path.length() - 6);
                serviceLocationList.add(fullName);
            } else {
                if (flag) {
                    serviceLocationList.addAll(getAllClassNameByFile(f, flag, packageName));
                }
            }
        }
        return serviceLocationList;
    }

    //获取jar包中的类信息
    private static List<String> getClassNameByJar(String jarPath, boolean childPackage, String packageName) {
        List<String> myClassName = new ArrayList<>();
        String[] jarInfo = jarPath.split("!");
        String jarFilePath = jarInfo[0].substring(jarInfo[0].indexOf("/"));
        try {
            JarFile jarFile = new JarFile(jarFilePath);
            Enumeration<JarEntry> entrys = jarFile.entries();
            while (entrys.hasMoreElements()) {
                JarEntry jarEntry = entrys.nextElement();
                String entryName = jarEntry.getName();
                if (entryName.endsWith(".class")) {
                    String packagePath = packageName.replaceAll("\\.", "/");
                    if (entryName.contains(packagePath)) {
                        String className = entryName.replaceAll("/", ".").substring(entryName.indexOf(packagePath));
                        myClassName.add(className.substring(0, className.length() - 6));
                    }
                } else if (childPackage) {

                    //jar 包架构
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return myClassName;
    }
}

@Data
@AllArgsConstructor
@ToString
class ApiInfo {
    private String group;
    private String requestPath;
    private RequestMethod[] requestMethods;
    private String apiDetail;
    private Dict paramDict;
    private String responseType;
}